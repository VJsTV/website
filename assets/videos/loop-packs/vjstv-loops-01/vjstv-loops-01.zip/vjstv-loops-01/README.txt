VJs TV Loops 01
===============
Free VJ Loop Pack by VJs TV
https://vjstv.com

CONTENTS
--------
20 seamlessly looping abstract clips
UV geometry · Glitch textures · Cyberpunk light trails

SPECS
-----
Resolution : 1920x1080 Full HD
Frame Rate : 60 fps
Format     : MP4 (H.264)
License    : Commercial Use Included

USAGE
-----
- Extract to your media drive
- Load MP4s into Resolume, VDMX, or TouchDesigner
- All clips seamlessly loop, no crossfade needed
- Mix and layer freely in any VJ software

LICENSE
-------
Free for commercial and non-commercial use.
No credit required, but appreciated.
Full terms: https://vjstv.com/license

VJs TV — vjstv.com
